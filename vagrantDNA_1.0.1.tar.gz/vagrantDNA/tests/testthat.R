library(testthat)
library(vagrantDNA)

test_check("vagrantDNA")
