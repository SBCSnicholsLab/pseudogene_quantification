#' NUMT datasets
#'
#' These data sets give allele frequencies generated from whole-genome
#' sequencing data mapped against mitochondrial genome references.
#'
#' `band_instruments` and `band_instruments2` contain the same data but use
#' different column names for the first column of the data set.
#' `band_instruments` uses `name`, which matches the name of the key column of
#' `band_members`; `band_instruments2` uses `artist`, which does not.
#'
#' @format Each is a data.frame, [species]DF just contain variant calling data.
#' [species]FX were generated from species with diverged populations. These
#' contain information on sites with fixed differences.
#' @examples
#' humanDF
#' parrotDF
#' hopperFX
#' parrotFX
"band_members"

#' @rdname band_members
#' @format NULL
"band_instruments"

#' @rdname band_members
#' @format NULL
"band_instruments2"
